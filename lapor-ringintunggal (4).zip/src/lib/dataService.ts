import { supabase } from './supabase';
import { Pengaduan, Tanggapan, generateTicketNumber } from '../types';

// Mock/Initial Data for fallback and rich demo experience
const INITIAL_COMPLAINTS: Pengaduan[] = [
  {
    id: 'e1b2c3d4-a1b2-c3d4-d5e6-f7a8b9c0d1e2',
    nama: 'Ahmad Subarjo',
    whatsapp: '081234567890',
    judul: 'Jalan Amblas Dekat Jembatan Sungai Samin',
    isi: 'Mohon perhatian bapak/ibu perangkat desa, jalan aspal di dekat jembatan Sungai Samin amblas sedalam kira-kira 30cm. Sangat membahayakan bagi pengendara motor yang lewat di malam hari karena penerangan jalan juga kurang.',
    kategori: 'Jalan Rusak',
    is_anonim: false,
    is_public: true,
    status: 'Diproses',
    created_at: new Date(Date.now() - 3600000 * 24 * 2).toISOString(), // 2 days ago
    updated_at: new Date(Date.now() - 3600000 * 12).toISOString(), // 12 hours ago
    foto_url: 'https://images.unsplash.com/photo-1515162305285-0293e4767cc2?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'f2c3d4e5-b2c3-d4e5-e6f7-a8b9c0d1e2f3',
    nama: 'Warga Ringintunggal',
    judul: 'Lampu Jalan Mati di RT 04 / RW 02',
    isi: 'Lampu penerangan jalan umum di tiang listrik depan mushola RT 04 mati sejak satu minggu yang lalu. Keadaan jalan menjadi sangat gelap gulita saat malam hari dan rawan tindakan pencurian. Mohon segera diperbaiki.',
    kategori: 'Lampu Jalan',
    is_anonim: true,
    is_public: true,
    status: 'Menunggu Verifikasi',
    created_at: new Date(Date.now() - 3600000 * 8).toISOString(), // 8 hours ago
    updated_at: new Date(Date.now() - 3600000 * 8).toISOString(),
  },
  {
    id: 'a3b4c5d6-c3d4-e5f6-a7b8-c9d0e1f2a3b4',
    nama: 'Budi Santoso',
    whatsapp: '085711223344',
    judul: 'Penumpukan Sampah Liar di Pinggir Sawah RT 10',
    isi: 'Ada oknum yang membuang tumpukan sampah plastik dalam jumlah besar di pinggir jalan persawahan RT 10. Baunya sangat menyengat dan mengotori saluran irigasi sawah warga. Kami memohon agar dipasang papan larangan membuang sampah di lokasi tersebut.',
    kategori: 'Sampah',
    is_anonim: false,
    is_public: true,
    status: 'Selesai',
    created_at: new Date(Date.now() - 3600000 * 24 * 5).toISOString(), // 5 days ago
    updated_at: new Date(Date.now() - 3600000 * 24 * 1).toISOString(), // 1 day ago
    foto_url: 'https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'b4c5d6e7-d4e5-f6a7-b8c9-d0e1f2a3b4c5',
    nama: 'Siti Aminah',
    whatsapp: '08987654321',
    judul: 'Pertanyaan Jadwal Penyaluran BLT Bulan Juni',
    isi: 'Selamat pagi, saya ingin menanyakan kapan kiranya bantuan langsung tunai (BLT) untuk bulan Juni ini akan dibagikan ya? Karena beberapa tetangga desa sebelah sudah menerima bantuan tersebut. Terima kasih atas informasinya.',
    kategori: 'Bantuan Sosial',
    is_anonim: false,
    is_public: true,
    status: 'Selesai',
    created_at: new Date(Date.now() - 3600000 * 24 * 10).toISOString(),
    updated_at: new Date(Date.now() - 3600000 * 24 * 8).toISOString(),
  }
];

const INITIAL_RESPONSES: Tanggapan[] = [
  {
    id: 'r1',
    pengaduan_id: 'e1b2c3d4-a1b2-c3d4-d5e6-f7a8b9c0d1e2',
    admin_email: 'admin@ringintunggal.desa.id',
    isi_tanggapan: 'Terima kasih atas laporannya Pak Ahmad. Kami dari pihak Kelurahan Desa Ringintunggal sudah berkoordinasi dengan Dinas PU Kecamatan untuk melakukan survei lokasi hari ini. Perbaikan darurat berupa penambalan akan diupayakan secepatnya.',
    created_at: new Date(Date.now() - 3600000 * 12).toISOString(),
  },
  {
    id: 'r2',
    pengaduan_id: 'a3b4c5d6-c3d4-e5f6-a7b8-c9d0e1f2a3b4',
    admin_email: 'admin@ringintunggal.desa.id',
    isi_tanggapan: 'Laporan telah kami terima dan tindaklanjuti. Petugas kebersihan desa didampingi bapak RT setempat telah bergotong-royong membersihkan tumpukan sampah tersebut kemarin siang. Papan peringatan dilarang membuang sampah juga telah dipasang di lokasi. Terima kasih atas kepeduliannya menjaga lingkungan Desa Ringintunggal.',
    created_at: new Date(Date.now() - 3600000 * 24 * 1).toISOString(),
  },
  {
    id: 'r3',
    pengaduan_id: 'b4c5d6e7-d4e5-f6a7-b8c9-d0e1f2a3b4c5',
    admin_email: 'admin@ringintunggal.desa.id',
    isi_tanggapan: 'Halo Bu Siti, untuk BLT Dana Desa bulan Juni saat ini sedang dalam tahap pencairan di tingkat kabupaten. Diperkirakan jadwal pembagian di Balai Desa Ringintunggal akan dilaksanakan pada hari Rabu, 1 Juli 2026. Undangan resmi akan dibagikan melalui ketua RT masing-masing.',
    created_at: new Date(Date.now() - 3600000 * 24 * 8).toISOString(),
  }
];

// Custom local storage implementation to keep fallback operational
class LocalDataService {
  private getComplaints(): Pengaduan[] {
    const data = localStorage.getItem('lapor_complaints');
    if (!data) {
      localStorage.setItem('lapor_complaints', JSON.stringify(INITIAL_COMPLAINTS));
      return INITIAL_COMPLAINTS;
    }
    return JSON.parse(data);
  }

  private saveComplaints(complaints: Pengaduan[]) {
    localStorage.setItem('lapor_complaints', JSON.stringify(complaints));
  }

  private getResponses(): Tanggapan[] {
    const data = localStorage.getItem('lapor_responses');
    if (!data) {
      localStorage.setItem('lapor_responses', JSON.stringify(INITIAL_RESPONSES));
      return INITIAL_RESPONSES;
    }
    return JSON.parse(data);
  }

  private saveResponses(responses: Tanggapan[]) {
    localStorage.setItem('lapor_responses', JSON.stringify(responses));
  }

  async fetchLatestComplaints(limit = 20): Promise<Pengaduan[]> {
    const complaints = this.getComplaints();
    return complaints
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, limit)
      .map(c => ({
        ...c,
        ticket_number: generateTicketNumber(c.id, c.created_at),
      }));
  }

  async getComplaintCount(): Promise<{ total: number; new: number; processing: number; completed: number }> {
    const complaints = this.getComplaints();
    return {
      total: complaints.length,
      new: complaints.filter(c => c.status === 'Menunggu Verifikasi').length,
      processing: complaints.filter(c => c.status === 'Diproses').length,
      completed: complaints.filter(c => c.status === 'Selesai').length,
    };
  }

  async searchAndFilterComplaints(
    searchQuery: string,
    statusFilter: string,
    categoryFilter: string,
    monthFilter: string
  ): Promise<Pengaduan[]> {
    let complaints = this.getComplaints();

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      complaints = complaints.filter(c => {
        const ticket = generateTicketNumber(c.id, c.created_at).toLowerCase();
        return (
          c.judul.toLowerCase().includes(q) ||
          c.isi.toLowerCase().includes(q) ||
          ticket.includes(q)
        );
      });
    }

    if (statusFilter) {
      complaints = complaints.filter(c => c.status === statusFilter);
    }

    if (categoryFilter) {
      complaints = complaints.filter(c => c.kategori === categoryFilter);
    }

    if (monthFilter) {
      // monthFilter: "YYYY-MM"
      complaints = complaints.filter(c => c.created_at.startsWith(monthFilter));
    }

    return complaints
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .map(c => ({
        ...c,
        ticket_number: generateTicketNumber(c.id, c.created_at),
      }));
  }

  async createComplaint(data: Omit<Pengaduan, 'id' | 'created_at' | 'updated_at' | 'status'>): Promise<Pengaduan> {
    const complaints = this.getComplaints();
    const newComplaint: Pengaduan = {
      ...data,
      id: crypto.randomUUID(),
      status: 'Menunggu Verifikasi',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    complaints.unshift(newComplaint);
    this.saveComplaints(complaints);
    return {
      ...newComplaint,
      ticket_number: generateTicketNumber(newComplaint.id, newComplaint.created_at),
    };
  }

  async getComplaintDetail(id: string): Promise<{ complaint: Pengaduan; responses: Tanggapan[] }> {
    const complaints = this.getComplaints();
    const complaint = complaints.find(c => c.id === id);
    if (!complaint) throw new Error('Pengaduan tidak ditemukan.');

    const responses = this.getResponses().filter(r => r.pengaduan_id === id);
    return {
      complaint: {
        ...complaint,
        ticket_number: generateTicketNumber(complaint.id, complaint.created_at),
      },
      responses: responses.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()),
    };
  }

  async addResponse(pengaduanId: string, adminEmail: string, isi: string): Promise<Tanggapan> {
    const responses = this.getResponses();
    const newResponse: Tanggapan = {
      id: crypto.randomUUID(),
      pengaduan_id: pengaduanId,
      admin_email: adminEmail,
      isi_tanggapan: isi,
      created_at: new Date().toISOString(),
    };
    responses.push(newResponse);
    this.saveResponses(responses);

    // Update complaint's updated_at
    const complaints = this.getComplaints();
    const index = complaints.findIndex(c => c.id === pengaduanId);
    if (index !== -1) {
      complaints[index].updated_at = new Date().toISOString();
      this.saveComplaints(complaints);
    }

    return newResponse;
  }

  async updateComplaintStatus(id: string, status: Pengaduan['status']): Promise<void> {
    const complaints = this.getComplaints();
    const index = complaints.findIndex(c => c.id === id);
    if (index !== -1) {
      complaints[index].status = status;
      complaints[index].updated_at = new Date().toISOString();
      this.saveComplaints(complaints);
    } else {
      throw new Error('Pengaduan tidak ditemukan.');
    }
  }

  async deleteComplaint(id: string): Promise<void> {
    const complaints = this.getComplaints();
    const filtered = complaints.filter(c => c.id !== id);
    this.saveComplaints(filtered);

    const responses = this.getResponses().filter(r => r.pengaduan_id !== id);
    this.saveResponses(responses);
  }
}

const localService = new LocalDataService();

export const dataService = {
  // Flag indicating whether we are in demo fallback mode or live Supabase
  isDemoMode: false,

  async fetchLatestComplaints(limit = 20): Promise<{ data: Pengaduan[]; isDemo: boolean }> {
    try {
      const { data, error } = await supabase
        .from('pengaduan')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(limit);

      if (error) throw error;

      if (!data || data.length === 0) {
        // If live Supabase has no data, we fallback or just return empty list.
        // Let's seed initial complaints if table query works but is empty.
        console.log('Supabase table is connected but empty. Returning empty or local data.');
      }

      const formatted = data.map((c: any) => ({
        ...c,
        ticket_number: generateTicketNumber(c.id, c.created_at),
      }));

      return { data: formatted, isDemo: false };
    } catch (err: any) {
      console.warn('Using Local Storage demo mode because Supabase tables are not found/configured:', err.message || err);
      const data = await localService.fetchLatestComplaints(limit);
      return { data, isDemo: true };
    }
  },

  async getComplaintCount(): Promise<{ total: number; new: number; processing: number; completed: number; isDemo: boolean }> {
    try {
      const { data, error } = await supabase
        .from('pengaduan')
        .select('status');

      if (error) throw error;

      const stats = {
        total: data.length,
        new: data.filter((c: any) => c.status === 'Menunggu Verifikasi').length,
        processing: data.filter((c: any) => c.status === 'Diproses').length,
        completed: data.filter((c: any) => c.status === 'Selesai').length,
      };

      return { ...stats, isDemo: false };
    } catch (err) {
      const stats = await localService.getComplaintCount();
      return { ...stats, isDemo: true };
    }
  },

  async searchAndFilterComplaints(
    searchQuery: string,
    statusFilter: string,
    categoryFilter: string,
    monthFilter: string
  ): Promise<{ data: Pengaduan[]; isDemo: boolean }> {
    try {
      let query = supabase.from('pengaduan').select('*');

      if (statusFilter) {
        query = query.eq('status', statusFilter);
      }
      if (categoryFilter) {
        query = query.eq('kategori', categoryFilter);
      }

      const { data, error } = await query.order('created_at', { ascending: false });
      if (error) throw error;

      let filtered = data;

      // Filter by month in JS for compatibility with standard ISO timestamp filters
      if (monthFilter) {
        filtered = filtered.filter((c: any) => c.created_at.startsWith(monthFilter));
      }

      // Filter by search term in JS (easier to support ticket_number + title + desc in one search)
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        filtered = filtered.filter((c: any) => {
          const ticket = generateTicketNumber(c.id, c.created_at).toLowerCase();
          return (
            c.judul.toLowerCase().includes(q) ||
            c.isi.toLowerCase().includes(q) ||
            ticket.includes(q)
          );
        });
      }

      const formatted = filtered.map((c: any) => ({
        ...c,
        ticket_number: generateTicketNumber(c.id, c.created_at),
      }));

      return { data: formatted, isDemo: false };
    } catch (err) {
      const data = await localService.searchAndFilterComplaints(searchQuery, statusFilter, categoryFilter, monthFilter);
      return { data, isDemo: true };
    }
  },

  async createComplaint(payload: Omit<Pengaduan, 'id' | 'created_at' | 'updated_at' | 'status'>): Promise<{ data: Pengaduan; isDemo: boolean }> {
    try {
      const { data, error } = await supabase
        .from('pengaduan')
        .insert([
          {
            nama: payload.nama || null,
            whatsapp: payload.whatsapp || null,
            judul: payload.judul,
            isi: payload.isi,
            kategori: payload.kategori,
            is_anonim: payload.is_anonim,
            is_public: payload.is_public,
            foto_url: payload.foto_url || null,
            status: 'Menunggu Verifikasi',
          }
        ])
        .select();

      if (error) throw error;
      if (!data || data.length === 0) throw new Error('Gagal memasukkan data pengaduan.');

      const created = data[0];
      return {
        data: {
          ...created,
          ticket_number: generateTicketNumber(created.id, created.created_at),
        },
        isDemo: false,
      };
    } catch (err) {
      const created = await localService.createComplaint(payload);
      return { data: created, isDemo: true };
    }
  },

  async getComplaintDetail(id: string): Promise<{ complaint: Pengaduan; responses: Tanggapan[]; isDemo: boolean }> {
    try {
      const complaintRes = await supabase.from('pengaduan').select('*').eq('id', id).single();
      if (complaintRes.error) throw complaintRes.error;

      const responsesRes = await supabase.from('tanggapan').select('*').eq('pengaduan_id', id).order('created_at', { ascending: true });
      // It is okay if responses are empty or have some errors
      const responses = responsesRes.data || [];

      return {
        complaint: {
          ...complaintRes.data,
          ticket_number: generateTicketNumber(complaintRes.data.id, complaintRes.data.created_at),
        },
        responses,
        isDemo: false,
      };
    } catch (err) {
      const data = await localService.getComplaintDetail(id);
      return { ...data, isDemo: true };
    }
  },

  async addResponse(pengaduanId: string, adminEmail: string, isi: string): Promise<{ data: Tanggapan; isDemo: boolean }> {
    try {
      const { data, error } = await supabase
        .from('tanggapan')
        .insert([
          {
            pengaduan_id: pengaduanId,
            admin_email: adminEmail,
            isi_tanggapan: isi,
          }
        ])
        .select();

      if (error) throw error;
      if (!data || data.length === 0) throw new Error('Gagal mengirim tanggapan.');

      // update complaint updated_at timestamp in background
      await supabase
        .from('pengaduan')
        .update({ updated_at: new Date().toISOString() })
        .eq('id', pengaduanId);

      return { data: data[0], isDemo: false };
    } catch (err) {
      const response = await localService.addResponse(pengaduanId, adminEmail, isi);
      return { data: response, isDemo: true };
    }
  },

  async updateComplaintStatus(id: string, status: Pengaduan['status']): Promise<{ success: boolean; isDemo: boolean }> {
    try {
      const { error } = await supabase
        .from('pengaduan')
        .update({ status, updated_at: new Date().toISOString() })
        .eq('id', id);

      if (error) throw error;
      return { success: true, isDemo: false };
    } catch (err) {
      await localService.updateComplaintStatus(id, status);
      return { success: true, isDemo: true };
    }
  },

  async deleteComplaint(id: string): Promise<{ success: boolean; isDemo: boolean }> {
    try {
      // Delete any associated responses first to prevent foreign key errors
      await supabase.from('tanggapan').delete().eq('pengaduan_id', id);

      const { error } = await supabase.from('pengaduan').delete().eq('id', id);
      if (error) throw error;

      return { success: true, isDemo: false };
    } catch (err) {
      await localService.deleteComplaint(id);
      return { success: true, isDemo: true };
    }
  }
};
