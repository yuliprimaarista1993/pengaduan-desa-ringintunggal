export interface Pengaduan {
  id: string; // uuid
  nama?: string;
  whatsapp?: string;
  judul: string;
  isi: string;
  kategori: string;
  is_anonim: boolean;
  is_public: boolean;
  foto_url?: string;
  status: 'Menunggu Verifikasi' | 'Diproses' | 'Selesai' | 'Ditolak';
  created_at: string;
  updated_at: string;
  // Computed property
  ticket_number?: string;
}

export interface Tanggapan {
  id: string; // uuid
  pengaduan_id: string;
  admin_email: string;
  isi_tanggapan: string;
  created_at: string;
}

export interface AdminUser {
  id: string; // uuid
  email: string;
  nama: string;
  role: string;
  created_at: string;
}

export type KategoriType =
  | 'Jalan Rusak'
  | 'Lampu Jalan'
  | 'Sampah'
  | 'Pelayanan Desa'
  | 'Bantuan Sosial'
  | 'Keamanan'
  | 'Infrastruktur'
  | 'Lingkungan'
  | 'Lainnya';

export const KATEGORI_LIST: KategoriType[] = [
  'Jalan Rusak',
  'Lampu Jalan',
  'Sampah',
  'Pelayanan Desa',
  'Bantuan Sosial',
  'Keamanan',
  'Infrastruktur',
  'Lingkungan',
  'Lainnya',
];

export type StatusType = 'Menunggu Verifikasi' | 'Diproses' | 'Selesai' | 'Ditolak';

export const STATUS_LIST: StatusType[] = [
  'Menunggu Verifikasi',
  'Diproses',
  'Selesai',
  'Ditolak',
];

// Helper to generate a standardized ticket number RGT-YYYYMMDD-XXXX from UUID and date
export function generateTicketNumber(id: string, createdAtStr: string): string {
  try {
    const date = new Date(createdAtStr);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const suffix = id.substring(0, 4).toUpperCase();
    return `RGT-${year}${month}${day}-${suffix}`;
  } catch (e) {
    const fallbackSuffix = id.substring(0, 4).toUpperCase() || 'XXXX';
    return `RGT-20260628-${fallbackSuffix}`;
  }
}
