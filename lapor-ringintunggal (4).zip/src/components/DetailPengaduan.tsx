import { useState, useEffect, FormEvent } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Clock, MessageSquare, AlertCircle, CheckCircle2, RefreshCw, Send, Trash2, ShieldAlert, BookOpen } from 'lucide-react';
import { Pengaduan, Tanggapan } from '../types';
import { dataService } from '../lib/dataService';

interface DetailPengaduanProps {
  id: string;
  onNavigate: (view: 'beranda' | 'buat-pengaduan' | 'detail' | 'login-admin' | 'admin-dashboard', ticketId?: string) => void;
  isAdmin: boolean;
  adminEmail: string | null;
  setDemoNotification: (val: boolean) => void;
}

export default function DetailPengaduan({ id, onNavigate, isAdmin, adminEmail, setDemoNotification }: DetailPengaduanProps) {
  const [complaint, setComplaint] = useState<Pengaduan | null>(null);
  const [responses, setResponses] = useState<Tanggapan[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [isDemo, setIsDemo] = useState(false);

  // Admin interactive states
  const [newResponseText, setNewResponseText] = useState('');
  const [newStatus, setNewStatus] = useState<Pengaduan['status'] | ''>('');
  const [submittingResponse, setSubmittingResponse] = useState(false);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [deletingComplaint, setDeletingComplaint] = useState(false);

  useEffect(() => {
    fetchDetail();
  }, [id]);

  const fetchDetail = async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      const res = await dataService.getComplaintDetail(id);
      setComplaint(res.complaint);
      setResponses(res.responses);
      setNewStatus(res.complaint.status);
      setIsDemo(res.isDemo);
      if (res.isDemo) {
        setDemoNotification(true);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Gagal memuat rincian laporan pengaduan.');
    } finally {
      setLoading(false);
    }
  };

  const handleAddResponse = async (e: FormEvent) => {
    e.preventDefault();
    if (!newResponseText.trim() || !complaint) return;

    setSubmittingResponse(true);
    try {
      const activeAdminEmail = adminEmail || 'admin@ringintunggal.desa.id';
      const res = await dataService.addResponse(complaint.id, activeAdminEmail, newResponseText.trim());

      // If status also changed, update it too
      if (newStatus && newStatus !== complaint.status) {
        await dataService.updateComplaintStatus(complaint.id, newStatus);
      }

      setNewResponseText('');
      await fetchDetail(); // Refresh data
    } catch (err: any) {
      alert(err.message || 'Gagal mengirimkan balasan admin.');
    } finally {
      setSubmittingResponse(false);
    }
  };

  const handleStatusChangeOnly = async (status: Pengaduan['status']) => {
    if (!complaint) return;
    setUpdatingStatus(true);
    try {
      await dataService.updateComplaintStatus(complaint.id, status);
      await fetchDetail();
    } catch (err: any) {
      alert(err.message || 'Gagal memperbarui status laporan.');
    } finally {
      setUpdatingStatus(false);
    }
  };

  const handleDeleteComplaint = async () => {
    if (!complaint) return;
    const confirmDelete = window.confirm(
      'Apakah Anda sangat yakin ingin menghapus laporan ini? Tindakan ini tidak dapat dibatalkan dan akan membersihkan semua balasan terkait.'
    );
    if (!confirmDelete) return;

    setDeletingComplaint(true);
    try {
      await dataService.deleteComplaint(complaint.id);
      alert('Laporan berhasil dihapus karena tergolong spam atau tidak valid.');
      onNavigate(isAdmin ? 'admin-dashboard' : 'beranda');
    } catch (err: any) {
      alert(err.message || 'Gagal menghapus laporan.');
      setDeletingComplaint(false);
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }) + ' WIB';
    } catch (e) {
      return dateStr;
    }
  };

  // Timeline computation based on Statuses
  const getTimelineSteps = () => {
    if (!complaint) return [];
    const status = complaint.status;

    const steps = [
      { key: 'diterima', label: 'Diterima', desc: 'Laporan warga berhasil masuk ke sistem desa.', done: true },
      {
        key: 'diverifikasi',
        label: 'Diverifikasi',
        desc: 'Admin memeriksa isi laporan dan kesesuaian kategori.',
        done: status !== 'Menunggu Verifikasi',
      },
      {
        key: 'diproses',
        label: 'Sedang Diproses',
        desc: 'Laporan dikoordinasikan dengan aparat/instansi terkait.',
        done: status === 'Diproses' || status === 'Selesai',
      },
      {
        key: 'selesai',
        label: 'Selesai',
        desc: 'Keluhan selesai diperbaiki atau dijawab secara tuntas.',
        done: status === 'Selesai',
      },
    ];

    if (status === 'Ditolak') {
      steps[1] = {
        key: 'ditolak',
        label: 'Laporan Ditolak',
        desc: 'Laporan tidak sesuai ketentuan atau tergolong spam.',
        done: true,
      };
      // Shorten timeline for rejected tickets
      return steps.slice(0, 2);
    }

    return steps;
  };

  const getStatusColorClass = (status: Pengaduan['status']) => {
    switch (status) {
      case 'Menunggu Verifikasi':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Diproses':
        return 'bg-teal-100 text-teal-800 border-teal-200';
      case 'Selesai':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Ditolak':
        return 'bg-rose-100 text-rose-800 border-rose-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  if (loading) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center">
        <div className="w-10 h-10 border-4 border-[#0F766E] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-sm text-slate-500">Memuat rincian laporan pengaduan...</p>
      </div>
    );
  }

  if (errorMsg || !complaint) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center">
        <div className="text-4xl mb-3">⚠️</div>
        <h2 className="text-base font-bold text-slate-800 mb-1">Terjadi Kesalahan</h2>
        <p className="text-xs text-slate-500 mb-6">{errorMsg || 'Laporan pengaduan tidak ditemukan.'}</p>
        <button
          id="btn-back-error"
          onClick={() => onNavigate(isAdmin ? 'admin-dashboard' : 'beranda')}
          className="inline-flex items-center gap-2 bg-[#0F766E] hover:bg-[#0D5C56] text-white text-xs font-semibold px-4 py-2 rounded-xl cursor-pointer"
        >
          Kembali
        </button>
      </div>
    );
  }

  const timelineSteps = getTimelineSteps();

  return (
    <div className="max-w-xl mx-auto px-4 pt-6 pb-24">
      {/* Back Header controls */}
      <div className="flex justify-between items-center mb-6">
        <button
          id="btn-back-detail"
          onClick={() => onNavigate(isAdmin ? 'admin-dashboard' : 'beranda')}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-slate-800 group cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          Kembali ke {isAdmin ? 'Dashboard Admin' : 'Beranda'}
        </button>

        <span className={`text-xs font-bold px-3 py-1 rounded-full border ${getStatusColorClass(complaint.status)}`}>
          {complaint.status}
        </span>
      </div>

      {/* Title & Metadata Card */}
      <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm mb-5">
        <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono mb-2">
          <span>{complaint.ticket_number || 'RGT-PENDING'}</span>
          <span>{formatDate(complaint.created_at)}</span>
        </div>

        <span className="inline-block text-xs font-medium bg-slate-100 text-slate-600 rounded-md px-2.5 py-1 mb-3">
          {complaint.kategori}
        </span>

        <h1 className="text-xl font-bold text-slate-900 tracking-tight leading-snug mb-3 font-display">
          {complaint.judul}
        </h1>

        {/* Reporter info */}
        <div className="flex items-center gap-2 text-xs text-slate-500 border-t border-slate-50 pt-3">
          <span className="font-semibold text-slate-700">Pelapor:</span>
          <span>
            {complaint.is_anonim ? (
              <span className="text-slate-500 italic flex items-center gap-1">
                Warga Ringintunggal (Anonim)
              </span>
            ) : (
              <span>{complaint.nama || 'Anonim'}</span>
            )}
          </span>
          {/* Masked WhatsApp for public, full for admin */}
          {!complaint.is_anonim && complaint.whatsapp && (
            <>
              <span className="text-slate-300">•</span>
              <span className="font-mono">
                {isAdmin ? (
                  <a href={`https://wa.me/${complaint.whatsapp}`} target="_blank" rel="noreferrer" className="text-teal-600 hover:underline">
                    {complaint.whatsapp} (Hubungi)
                  </a>
                ) : (
                  <span>{complaint.whatsapp.substring(0, 5)}xxxxxx</span>
                )}
              </span>
            </>
          )}
        </div>
      </div>

      {/* Progress Tracker Progress Bar */}
      <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm mb-5">
        <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-1.5">
          <Clock className="w-4 h-4 text-[#0F766E]" />
          Pelacakan Proses Laporan
        </h3>

        <div className="relative pl-6 border-l-2 border-slate-100 space-y-5 ml-2.5 py-1">
          {timelineSteps.map((step, index) => (
            <div key={step.key} className="relative">
              {/* Point Node icon indicator */}
              <div
                className={`absolute -left-[31px] top-0.5 w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                  step.done
                    ? 'bg-emerald-500 border-emerald-500 text-white'
                    : 'bg-white border-slate-300'
                }`}
              >
                {step.done && <span className="text-[9px]">✓</span>}
              </div>

              <div>
                <h4 className={`text-xs font-bold leading-none mb-1 ${step.done ? 'text-slate-800' : 'text-slate-400'}`}>
                  {step.label}
                </h4>
                <p className="text-[10px] text-slate-400 leading-normal">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Complaint Content & Photo Attachment */}
      <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm mb-5">
        <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3">Detail Laporan</h3>
        <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-wrap mb-4">
          {complaint.isi}
        </p>

        {complaint.foto_url && (
          <div className="border border-slate-100 rounded-xl overflow-hidden mt-2">
            <span className="block text-[10px] text-slate-400 bg-slate-50 px-3 py-1.5 font-medium border-b border-slate-100">
              Foto Lampiran Bukti:
            </span>
            <a href={complaint.foto_url} target="_blank" rel="noreferrer" title="Klik untuk membuka ukuran penuh">
              <img
                src={complaint.foto_url}
                alt="Foto Bukti Pengaduan"
                className="w-full max-h-72 object-contain bg-slate-50 hover:opacity-95 transition-opacity"
              />
            </a>
          </div>
        )}
      </div>

      {/* Official Responses Section */}
      <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm mb-5">
        <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-1.5">
          <MessageSquare className="w-4 h-4 text-[#0F766E]" />
          Tanggapan Perangkat Desa ({responses.length})
        </h3>

        {responses.length === 0 ? (
          <div className="text-center py-6 bg-slate-50/50 rounded-xl border border-dashed border-slate-100 text-slate-400">
            <p className="text-xs">Belum ada tanggapan resmi dari pihak Desa Ringintunggal.</p>
            <p className="text-[10px] text-slate-400 mt-1">Laporan Anda sedang menunggu antrean verifikasi petugas.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {responses.map((res) => (
              <div key={res.id} className="bg-teal-50/20 border border-teal-50 rounded-xl p-4 space-y-1.5">
                <div className="flex justify-between items-center text-[10px]">
                  <span className="font-bold text-[#0F766E] flex items-center gap-1">
                    👑 Perangkat Desa Ringintunggal
                  </span>
                  <span className="text-slate-400 font-mono">{formatDate(res.created_at)}</span>
                </div>
                <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">
                  {res.isi_tanggapan}
                </p>
                <div className="text-[9px] text-slate-400 text-right">
                  Verifikator: {res.admin_email}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ADMIN CONTROL PANEL WORKBENCH */}
      {isAdmin && (
        <div className="bg-slate-900 text-white rounded-2xl p-5 border border-slate-800 shadow-md">
          <h3 className="text-xs font-bold text-teal-400 uppercase tracking-wider mb-4 flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4" />
            Admin Workbench (Aparat Desa)
          </h3>

          <form onSubmit={handleAddResponse} className="space-y-4">
            {/* Quick Status Setter */}
            <div className="space-y-1">
              <label className="block text-xs font-semibold text-slate-300">Ubah Status Pengaduan</label>
              <div className="grid grid-cols-2 gap-1">
                {['Menunggu Verifikasi', 'Diproses', 'Selesai', 'Ditolak'].map((st) => (
                  <button
                    key={st}
                    id={`btn-set-status-${st.replace(' ', '-').toLowerCase()}`}
                    type="button"
                    onClick={() => handleStatusChangeOnly(st as Pengaduan['status'])}
                    className={`px-2 py-1.5 text-[10px] font-bold rounded-lg border text-center transition-all cursor-pointer ${
                      complaint.status === st
                        ? 'bg-[#0F766E] text-white border-[#0F766E]'
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-750'
                    }`}
                  >
                    {complaint.status === st ? '● ' : ''}{st}
                  </button>
                ))}
              </div>
              {updatingStatus && <p className="text-[10px] text-teal-400 animate-pulse mt-1">Mengubah status di Supabase...</p>}
            </div>

            {/* Response content */}
            <div className="space-y-1">
              <label className="block text-xs font-semibold text-slate-300">Tulis Tanggapan Resmi</label>
              <textarea
                rows={4}
                placeholder="Berikan tanggapan, info dinas, atau hasil musyawarah warga..."
                value={newResponseText}
                onChange={(e) => setNewResponseText(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-teal-500"
              />
            </div>

            {/* Quick response templates */}
            <div className="space-y-1">
              <label className="block text-[9px] font-semibold text-slate-400">Gunakan Template Balasan Cepat</label>
              <div className="flex flex-wrap gap-1">
                <button
                  type="button"
                  onClick={() => setNewResponseText('Terima kasih atas laporannya. Laporan Anda telah kami teruskan ke Kepala Dusun setempat untuk ditinjau kondisinya siang ini. Perkembangan lanjut akan diupdate di sini.')}
                  className="bg-slate-800 hover:bg-slate-700 text-[9px] text-slate-300 px-2 py-1 rounded cursor-pointer"
                >
                  Diteruskan ke Kadus
                </button>
                <button
                  type="button"
                  onClick={() => setNewResponseText('Laporan selesai ditindaklanjuti. Staf kebersihan/keamanan desa telah menyelesaikan penanganan di lapangan sesuai keluhan Anda. Terima kasih atas kerja samanya.')}
                  className="bg-slate-800 hover:bg-slate-700 text-[9px] text-slate-300 px-2 py-1 rounded cursor-pointer"
                >
                  Selesai Penanganan
                </button>
              </div>
            </div>

            <div className="flex gap-2 pt-2 border-t border-slate-800">
              {/* Submit Reply */}
              <button
                id="btn-submit-tanggapan-admin"
                type="submit"
                disabled={submittingResponse || !newResponseText.trim()}
                className={`flex-1 py-2 rounded-xl text-xs font-bold text-center flex items-center justify-center gap-1 cursor-pointer ${
                  newResponseText.trim()
                    ? 'bg-teal-500 hover:bg-teal-600 text-slate-950'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {submittingResponse ? (
                  <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    Kirim Balasan
                  </>
                )}
              </button>

              {/* Spam Eraser */}
              <button
                id="btn-delete-spam"
                type="button"
                onClick={handleDeleteComplaint}
                disabled={deletingComplaint}
                className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-3 rounded-xl flex items-center justify-center gap-1 cursor-pointer"
                title="Hapus Laporan (Spam)"
              >
                {deletingComplaint ? (
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    Hapus
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
