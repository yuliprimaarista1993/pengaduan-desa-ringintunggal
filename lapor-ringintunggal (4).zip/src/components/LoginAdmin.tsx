import { useState, FormEvent } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, KeyRound, Mail, AlertTriangle, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface LoginAdminProps {
  onNavigate: (view: 'beranda' | 'buat-pengaduan' | 'detail' | 'login-admin' | 'admin-dashboard', ticketId?: string) => void;
  onLoginSuccess: (email: string, token?: string) => void;
  setDemoNotification: (val: boolean) => void;
}

export default function LoginAdmin({ onNavigate, onLoginSuccess, setDemoNotification }: LoginAdminProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleLogin = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!email.trim() || !password.trim()) {
      setErrorMsg('Email dan kata sandi wajib diisi.');
      return;
    }

    setLoading(true);
    try {
      // Try actual Supabase authentication
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password: password.trim(),
      });

      if (error) {
        // If Supabase fails (e.g. because Auth isn't configured, or tables aren't set up, or credential mismatch)
        // we check if they used our standard fallback guest account
        if (email.trim() === 'admin@ringintunggal.desa.id' && password.trim() === 'admin123') {
          setSuccessMsg('Login Demo berhasil! Membuka gerbang administrasi desa...');
          setDemoNotification(true);
          setTimeout(() => {
            onLoginSuccess('admin@ringintunggal.desa.id', 'local_demo_token');
            onNavigate('admin-dashboard');
          }, 1000);
          return;
        }
        throw error;
      }

      setSuccessMsg('Login berhasil! Mengalihkan ke dashboard...');
      setTimeout(() => {
        onLoginSuccess(data.user?.email || email.trim(), data.session?.access_token);
        onNavigate('admin-dashboard');
      }, 1000);

    } catch (err: any) {
      // Fallback fallback: If they typed the correct demo credentials but Supabase failed, let them in anyway!
      if (email.trim() === 'admin@ringintunggal.desa.id' && password.trim() === 'admin123') {
        setSuccessMsg('Login Demo berhasil! Membuka gerbang administrasi desa...');
        setDemoNotification(true);
        setTimeout(() => {
          onLoginSuccess('admin@ringintunggal.desa.id', 'local_demo_token');
          onNavigate('admin-dashboard');
        }, 1000);
        return;
      }
      setErrorMsg(err.message || 'Email atau kata sandi Anda salah. Harap periksa kembali.');
    } finally {
      setLoading(false);
    }
  };

  const handleFillDemo = () => {
    setEmail('admin@ringintunggal.desa.id');
    setPassword('admin123');
    setErrorMsg('');
  };

  return (
    <div className="max-w-md mx-auto px-4 pt-12 pb-24">
      {/* Back button */}
      <button
        id="btn-back-login"
        onClick={() => onNavigate('beranda')}
        className="inline-flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-slate-800 mb-8 group cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
        Kembali ke Beranda
      </button>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm"
      >
        {/* Logo and Greeting */}
        <div className="text-center mb-6">
          <img
            src="https://i.ibb.co.com/tTzpHtJc/logo-ringintunggal-1.webp"
            alt="Logo Desa Ringintunggal"
            className="w-16 h-16 mx-auto object-contain mb-3 drop-shadow"
            referrerPolicy="no-referrer"
          />
          <h1 className="text-xl font-bold text-slate-900 tracking-tight font-display mb-1">
            Login Admin Desa
          </h1>
          <p className="text-xs text-slate-500">
            Khusus aparat dan pengelola pengaduan Desa Ringintunggal.
          </p>
        </div>

        {errorMsg && (
          <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 mb-4 text-xs text-rose-700 flex gap-2 items-start">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 mb-4 text-xs text-emerald-700 flex gap-2 items-start">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          {/* Email */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-700">Alamat Email Admin</label>
            <div className="relative">
              <input
                type="email"
                placeholder="contoh: admin@ringintunggal.desa.id"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2.5 text-xs focus:outline-none focus:border-[#0F766E]"
                required
              />
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            </div>
          </div>

          {/* Password */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-700">Kata Sandi</label>
            <div className="relative">
              <input
                type="password"
                placeholder="Masukkan kata sandi Anda"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2.5 text-xs focus:outline-none focus:border-[#0F766E]"
                required
              />
              <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            </div>
          </div>

          {/* Submit */}
          <button
            id="btn-do-login"
            type="submit"
            disabled={loading}
            className="w-full bg-[#0F766E] hover:bg-[#0D5C56] text-white font-bold text-xs py-3 rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5"
          >
            {loading ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              'Masuk Sistem Admin'
            )}
          </button>
        </form>

        {/* Demo Account Quick Access Card */}
        <div className="mt-6 pt-5 border-t border-slate-100 text-center">
          <div className="bg-teal-50/50 rounded-xl p-4 border border-teal-50">
            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#0F766E] uppercase tracking-wider mb-1 bg-teal-50 px-2 py-0.5 rounded-full">
              <ShieldCheck className="w-3.5 h-3.5" />
              Sistem Demo Staf Desa
            </span>
            <p className="text-[10px] text-slate-500 mb-3 leading-normal">
              Gunakan kredensial pengelola di bawah untuk menguji gerbang admin dan membalas laporan warga secara simulasi.
            </p>
            <button
              id="btn-fill-demo-credentials"
              type="button"
              onClick={handleFillDemo}
              className="w-full bg-teal-600 hover:bg-teal-700 text-white text-[10px] font-bold py-2 px-3 rounded-lg transition-colors cursor-pointer"
            >
              Gunakan Akun Demo (Pre-fill)
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
