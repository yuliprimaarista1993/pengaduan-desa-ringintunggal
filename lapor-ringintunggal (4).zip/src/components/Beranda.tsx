import { useState, useEffect, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Filter, Plus, MessageSquare, Clock, ArrowRight, Shield, CheckCircle2, ChevronDown, RefreshCw, ClipboardList, CheckCircle, Flame, Sparkles } from 'lucide-react';
import { Pengaduan, KATEGORI_LIST, KategoriType } from '../types';
import { dataService } from '../lib/dataService';

interface BerandaProps {
  onNavigate: (view: 'beranda' | 'buat-pengaduan' | 'detail' | 'login-admin' | 'admin-dashboard', ticketId?: string) => void;
  demoNotification: boolean;
  setDemoNotification: (val: boolean) => void;
}

export default function Beranda({ onNavigate, demoNotification, setDemoNotification }: BerandaProps) {
  const [complaints, setComplaints] = useState<Pengaduan[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [monthFilter, setMonthFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [isDemo, setIsDemo] = useState(false);
  const [ticketSearch, setTicketSearch] = useState('');
  const [ticketError, setTicketError] = useState('');
  const [showTracker, setShowTracker] = useState(false);

  // Search/Filter debouncing/triggers
  useEffect(() => {
    fetchComplaints();
  }, [statusFilter, categoryFilter, monthFilter]);

  const fetchComplaints = async () => {
    setLoading(true);
    try {
      const res = await dataService.searchAndFilterComplaints(
        searchQuery,
        statusFilter,
        categoryFilter,
        monthFilter
      );
      setComplaints(res.data);
      setIsDemo(res.isDemo);
      if (res.isDemo) {
        setDemoNotification(true);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: FormEvent) => {
    e.preventDefault();
    fetchComplaints();
  };

  const handleTicketTrack = async (e: FormEvent) => {
    e.preventDefault();
    if (!ticketSearch.trim()) return;
    setTicketError('');

    const formattedSearch = ticketSearch.trim().toUpperCase();
    setLoading(true);
    try {
      // Fetch all to find match since we can compute/lookup ticket numbers
      const res = await dataService.searchAndFilterComplaints('', '', '', '');
      const match = res.data.find(
        c => c.ticket_number?.toUpperCase() === formattedSearch || c.id === ticketSearch
      );

      if (match) {
        onNavigate('detail', match.id);
      } else {
        setTicketError('Maaf, nomor tiket tidak ditemukan. Periksa kembali penulisan Anda.');
      }
    } catch (err) {
      setTicketError('Terjadi kesalahan saat melacak tiket.');
    } finally {
      setLoading(false);
    }
  };

  const getStatusStyle = (status: Pengaduan['status']) => {
    switch (status) {
      case 'Menunggu Verifikasi':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Diproses':
        return 'bg-teal-50 text-teal-700 border-teal-200';
      case 'Selesai':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Ditolak':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      });
    } catch (e) {
      return dateStr;
    }
  };

  return (
    <div className="pb-24 bg-gradient-to-b from-[#0F766E]/5 via-white to-white min-h-screen">
      {/* Hero Section */}
      <div className="relative overflow-hidden pt-10 pb-8 px-4">
        {/* Modern ambient background glows */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-72 h-72 bg-teal-400/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-20 left-10 w-48 h-48 bg-[#0F766E]/5 rounded-full blur-2xl pointer-events-none" />

        <div className="max-w-xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 100, delay: 0.05 }}
            className="inline-block relative mb-4"
          >
            <div className="absolute inset-0 bg-teal-500/20 rounded-full blur-xl animate-pulse" />
            <img
              src="https://i.ibb.co.com/tTzpHtJc/logo-ringintunggal-1.webp"
              alt="Logo Desa Ringintunggal"
              className="w-24 h-24 mx-auto object-contain relative z-10 filter drop-shadow-xl"
              referrerPolicy="no-referrer"
            />
          </motion.div>

          <motion.h1
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-3xl font-extrabold text-slate-900 tracking-tight font-display mb-2.5 bg-gradient-to-r from-teal-900 via-teal-800 to-slate-900 bg-clip-text text-transparent"
          >
            Lapor Ringintunggal
          </motion.h1>
          <motion.p
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.15 }}
            className="text-xs sm:text-sm text-slate-600 max-w-sm mx-auto leading-relaxed mb-6 font-medium"
          >
            Wadah komunikasi resmi dan transparan untuk menyampaikan laporan, keluhan, serta aspirasi demi kemajuan Desa Ringintunggal.
          </motion.p>
        </div>

        {/* Modern Call to Action Card & Flow Guidelines */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 90, delay: 0.2 }}
          className="max-w-md mx-auto bg-white/95 backdrop-blur-md rounded-3xl shadow-xl shadow-teal-950/5 border border-slate-100 p-6 relative overflow-hidden"
        >
          {/* Accent light bar at top */}
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-teal-500 via-emerald-500 to-teal-600" />
          
          <div className="text-center space-y-4">
            <div>
              <span className="inline-flex items-center gap-1 bg-teal-50 text-[#0F766E] font-bold text-[10px] tracking-wider uppercase px-3 py-1 rounded-full mb-2 border border-teal-100">
                <Sparkles className="w-3 h-3 text-teal-600" />
                Layanan Pengaduan Digital
              </span>
              <h2 className="text-lg font-bold text-slate-900 tracking-tight leading-snug">
                Ada Aspirasi atau Masalah?<br/>Laporkan Laporan Anda Sekarang
              </h2>
            </div>

            <div className="space-y-3">
              <button
                id="btn-laporkan-sekarang"
                onClick={() => onNavigate('buat-pengaduan')}
                className="w-full bg-gradient-to-r from-[#0F766E] to-[#115E59] hover:from-[#0D5C56] hover:to-[#0F766E] text-white font-bold text-sm rounded-2xl py-3.5 px-6 transition-all duration-200 shadow-lg shadow-[#0F766E]/10 flex items-center justify-center gap-2 group active:scale-[0.98] cursor-pointer"
              >
                <span>Mulai Sampaikan Laporan</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              {/* Step Flow timeline */}
              <div className="grid grid-cols-3 gap-2 pt-4 mt-2 border-t border-slate-100">
                <div className="text-center group">
                  <div className="w-8 h-8 bg-teal-50 group-hover:bg-teal-100 transition-colors text-[#0F766E] font-bold text-xs rounded-full flex items-center justify-center mx-auto mb-1 border border-teal-100 shadow-sm">
                    1
                  </div>
                  <span className="text-[10px] font-bold text-slate-800 block">Tulis Laporan</span>
                  <span className="text-[8px] text-slate-400 block mt-0.5 leading-tight">Lengkapi data secara detail</span>
                </div>
                <div className="text-center group">
                  <div className="w-8 h-8 bg-amber-50 group-hover:bg-amber-100 transition-colors text-amber-700 font-bold text-xs rounded-full flex items-center justify-center mx-auto mb-1 border border-amber-100 shadow-sm">
                    2
                  </div>
                  <span className="text-[10px] font-bold text-slate-800 block">Verifikasi</span>
                  <span className="text-[8px] text-slate-400 block mt-0.5 leading-tight">Tim staf meninjau laporan</span>
                </div>
                <div className="text-center group">
                  <div className="w-8 h-8 bg-emerald-50 group-hover:bg-emerald-100 transition-colors text-emerald-700 font-bold text-xs rounded-full flex items-center justify-center mx-auto mb-1 border border-emerald-100 shadow-sm">
                    3
                  </div>
                  <span className="text-[10px] font-bold text-slate-800 block">Tindak Lanjut</span>
                  <span className="text-[8px] text-slate-400 block mt-0.5 leading-tight">Solusi diselesaikan tuntas</span>
                </div>
              </div>
            </div>

            {/* Subtle expandable tracker toggle */}
            <div className="pt-3 border-t border-slate-50 flex flex-col items-center">
              <button
                type="button"
                onClick={() => setShowTracker(!showTracker)}
                className="text-xs text-[#0F766E] hover:text-[#0D5C56] font-semibold flex items-center gap-1.5 transition-colors cursor-pointer p-1 rounded-lg"
              >
                <span>{showTracker ? "▲ Sembunyikan Formulir Pelacakan" : "🔍 Sudah lapor? Lacak status tiket Anda di sini"}</span>
              </button>

              <AnimatePresence>
                {showTracker && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="w-full mt-3 overflow-hidden text-left"
                  >
                    <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
                      <label className="block text-[10px] font-bold text-slate-500 mb-1">KODE/NOMOR TIKET PENGADUAN</label>
                      <form onSubmit={handleTicketTrack} className="flex gap-2">
                        <input
                          type="text"
                          placeholder="Contoh: RGT-20260628-A4B2"
                          value={ticketSearch}
                          onChange={(e) => setTicketSearch(e.target.value)}
                          className="flex-1 bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono placeholder:text-slate-400 focus:outline-none focus:border-[#0F766E] uppercase"
                        />
                        <button
                          type="submit"
                          className="bg-slate-800 hover:bg-slate-950 text-white font-bold text-xs rounded-xl px-4 py-2 transition-colors cursor-pointer"
                        >
                          Lacak
                        </button>
                      </form>
                      {ticketError && (
                        <p className="text-[10px] text-rose-600 mt-2 font-semibold flex items-center gap-1">
                          <span>⚠️</span> {ticketError}
                        </p>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-xl mx-auto px-4 mt-4">
        {/* Dynamic Live Statistics Panel */}
        <div className="grid grid-cols-4 gap-2.5 mb-6 text-center">
          <div className="bg-gradient-to-br from-slate-50 to-slate-100/40 p-3 rounded-2xl border border-slate-150/60 shadow-sm transition-all hover:scale-102">
            <span className="block text-base font-extrabold text-slate-800 leading-none mb-1">{complaints.length}</span>
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">Total</span>
          </div>
          <div className="bg-gradient-to-br from-amber-50 to-amber-100/30 p-3 rounded-2xl border border-amber-200/40 shadow-sm transition-all hover:scale-102">
            <span className="block text-base font-extrabold text-amber-700 leading-none mb-1">
              {complaints.filter(c => c.status === 'Menunggu Verifikasi').length}
            </span>
            <span className="text-[9px] font-bold text-amber-500 uppercase tracking-wider block">Menunggu</span>
          </div>
          <div className="bg-gradient-to-br from-teal-50 to-teal-100/30 p-3 rounded-2xl border border-teal-200/40 shadow-sm transition-all hover:scale-102">
            <span className="block text-base font-extrabold text-[#0F766E] leading-none mb-1">
              {complaints.filter(c => c.status === 'Diproses').length}
            </span>
            <span className="text-[9px] font-bold text-teal-600 uppercase tracking-wider block">Proses</span>
          </div>
          <div className="bg-gradient-to-br from-emerald-50 to-emerald-100/30 p-3 rounded-2xl border border-emerald-200/40 shadow-sm transition-all hover:scale-102">
            <span className="block text-base font-extrabold text-emerald-700 leading-none mb-1">
              {complaints.filter(c => c.status === 'Selesai').length}
            </span>
            <span className="text-[9px] font-bold text-emerald-600 uppercase tracking-wider block">Selesai</span>
          </div>
        </div>

        {/* Banner Informational for Supabase Setup */}
        {demoNotification && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-6 relative">
            <button
              className="absolute top-2 right-2 text-slate-400 hover:text-slate-600 text-lg font-bold w-6 h-6 flex items-center justify-center rounded-full bg-amber-100/50"
              onClick={() => setDemoNotification(false)}
            >
              ×
            </button>
            <div className="flex gap-3">
              <div className="text-lg">📢</div>
              <div>
                <h4 className="text-xs font-bold text-amber-800 mb-0.5">Mode Demonstrasi Aktif</h4>
                <p className="text-xs text-amber-700 leading-relaxed">
                  Aplikasi saat ini berjalan menggunakan <strong>Local Storage</strong> karena tabel database Supabase belum terdeteksi. Semua fitur (tambah laporan, ganti status, balasan admin) tetap berfungsi 100% secara lokal untuk uji coba.
                </p>
                <div className="mt-2 text-[10px] text-amber-600 font-mono bg-amber-100/40 p-1.5 rounded-lg">
                  Gunakan akun Admin demo: <span className="font-bold underline">admin@ringintunggal.desa.id</span> dengan password <span className="font-bold underline">admin123</span> di menu Admin.
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Search & Filters */}
        <div className="mb-6 space-y-3">
          <form onSubmit={handleSearchSubmit} className="relative">
            <input
              type="text"
              placeholder="Cari pengaduan berdasarkan judul atau isi..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-2xl pl-11 pr-4 py-3.5 text-sm focus:outline-none focus:border-[#0F766E] focus:ring-4 focus:ring-[#0F766E]/5 transition-all placeholder:text-slate-400 shadow-sm"
            />
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-4" />
          </form>

          {/* Expanded Filters Panel */}
          <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider">
              <Filter className="w-3.5 h-3.5 text-[#0F766E]" />
              Saring Laporan
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-1 uppercase tracking-wider">Kategori</label>
                <div className="relative">
                  <select
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2.5 text-xs font-medium focus:outline-none focus:border-[#0F766E] appearance-none"
                  >
                    <option value="">Semua Kategori</option>
                    {KATEGORI_LIST.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-3.5 pointer-events-none" />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-1 uppercase tracking-wider">Status</label>
                <div className="relative">
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2.5 text-xs font-medium focus:outline-none focus:border-[#0F766E] appearance-none"
                  >
                    <option value="">Semua Status</option>
                    <option value="Menunggu Verifikasi">Menunggu Verifikasi</option>
                    <option value="Diproses">Diproses</option>
                    <option value="Selesai">Selesai</option>
                    <option value="Ditolak">Ditolak</option>
                  </select>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-3.5 pointer-events-none" />
                </div>
              </div>
            </div>

            {/* Quick reset button */}
            {(categoryFilter || statusFilter || searchQuery) && (
              <button
                id="btn-reset-filter"
                onClick={() => {
                  setCategoryFilter('');
                  setStatusFilter('');
                  setSearchQuery('');
                  setMonthFilter('');
                }}
                className="w-full text-center text-xs font-bold text-[#0F766E] hover:text-[#0D5C56] py-2 bg-teal-50/50 hover:bg-teal-50 rounded-xl transition-colors cursor-pointer"
              >
                Atur Ulang Filter
              </button>
            )}
          </div>
        </div>

        {/* Complaints Section Header */}
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
            Laporan Terbaru ({complaints.length})
            {loading && <RefreshCw className="w-3.5 h-3.5 animate-spin text-teal-600" />}
          </h3>
          <span className="text-[11px] text-slate-400 font-semibold uppercase tracking-wider">Urutan: Terkini</span>
        </div>

        {/* Complaints List */}
        {loading && complaints.length === 0 ? (
          <div className="space-y-4">
            {[1, 2, 3].map((n) => (
              <div key={n} className="bg-white rounded-2xl p-5 border border-slate-100 animate-pulse space-y-3">
                <div className="flex justify-between items-center">
                  <div className="h-4 w-28 bg-slate-200 rounded" />
                  <div className="h-6 w-20 bg-slate-200 rounded-full" />
                </div>
                <div className="h-5 w-4/5 bg-slate-200 rounded" />
                <div className="h-10 w-full bg-slate-200 rounded" />
                <div className="flex justify-between items-center pt-2">
                  <div className="h-3 w-24 bg-slate-200 rounded" />
                  <div className="h-4 w-12 bg-slate-200 rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : complaints.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 border border-slate-100 text-center shadow-sm">
            <div className="text-4xl mb-3">📭</div>
            <h4 className="text-base font-bold text-slate-700 mb-1">Belum Ada Laporan</h4>
            <p className="text-xs text-slate-500 max-w-xs mx-auto mb-5 leading-relaxed">
              Tidak ditemukan pengaduan yang sesuai dengan pencarian Anda. Jadilah yang pertama menyampaikan laporan!
            </p>
            <button
              id="btn-buat-laporan-empty"
              onClick={() => onNavigate('buat-pengaduan')}
              className="inline-flex items-center gap-2 bg-[#0F766E] hover:bg-[#0D5C56] text-white font-medium text-xs rounded-xl px-4 py-2.5 transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Sampaikan Pengaduan Baru
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {complaints.map((c, idx) => {
              // Custom side border highlights matching status for modern layout
              let borderClass = 'border-l-4 border-l-slate-300';
              if (c.status === 'Menunggu Verifikasi') borderClass = 'border-l-4 border-l-amber-400';
              if (c.status === 'Diproses') borderClass = 'border-l-4 border-l-teal-500';
              if (c.status === 'Selesai') borderClass = 'border-l-4 border-l-emerald-500';
              if (c.status === 'Ditolak') borderClass = 'border-l-4 border-l-rose-500';

              return (
                <motion.div
                  key={c.id}
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.3, delay: Math.min(idx * 0.05, 0.4) }}
                  onClick={() => onNavigate('detail', c.id)}
                  className={`bg-white rounded-2xl border border-slate-150/80 shadow-sm hover:shadow-md transition-all duration-200 p-5 cursor-pointer relative overflow-hidden group hover:border-teal-500/25 ${borderClass}`}
                >
                  {/* Header info */}
                  <div className="flex justify-between items-start gap-2 mb-3">
                    <div className="space-y-1">
                      <span className="text-[10px] font-mono font-bold tracking-wider text-slate-400 block">
                        {c.ticket_number || 'RGT-PENDING'}
                      </span>
                      <span className="inline-block text-[10px] font-bold bg-slate-100 text-slate-600 rounded-md px-2 py-0.5 uppercase tracking-wider">
                        {c.kategori}
                      </span>
                    </div>
                    <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full border ${getStatusStyle(c.status)}`}>
                      ● {c.status}
                    </span>
                  </div>

                  {/* Body details */}
                  <h4 className="text-sm font-bold text-slate-900 group-hover:text-[#0F766E] transition-colors mb-1.5 leading-snug">
                    {c.judul}
                  </h4>
                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed mb-4">
                    {c.isi}
                  </p>

                  {/* Footer specs */}
                  <div className="flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-50 pt-3">
                    <span className="flex items-center gap-1 font-semibold">
                      {c.is_anonim ? (
                        <span className="text-slate-400 italic">Warga Anonim</span>
                      ) : (
                        <span className="text-slate-700">{c.nama || 'Anonim'}</span>
                      )}
                    </span>
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        {formatDate(c.created_at)}
                      </span>
                      <span className="flex items-center gap-1 text-[#0F766E] font-bold bg-[#0F766E]/5 px-2.5 py-1 rounded-full text-[10px] uppercase tracking-wider group-hover:bg-[#0F766E]/10 transition-colors">
                        <MessageSquare className="w-3.5 h-3.5" />
                        Lihat Detail
                      </span>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
