import { useState, useRef, ChangeEvent, DragEvent, TouchEvent, MouseEvent, FormEvent } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Send, Upload, ShieldCheck, Eye, EyeOff, User, Phone, CheckCircle, AlertTriangle } from 'lucide-react';
import { KATEGORI_LIST, KategoriType } from '../types';
import { dataService } from '../lib/dataService';

interface BuatPengaduanProps {
  onNavigate: (view: 'beranda' | 'buat-pengaduan' | 'detail' | 'login-admin' | 'admin-dashboard', ticketId?: string) => void;
  setDemoNotification: (val: boolean) => void;
}

export default function BuatPengaduan({ onNavigate, setDemoNotification }: BuatPengaduanProps) {
  // Form States
  const [judul, setJudul] = useState('');
  const [isi, setIsi] = useState('');
  const [kategori, setKategori] = useState<KategoriType | ''>('');
  const [nama, setNama] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [isAnonim, setIsAnonim] = useState(false);
  const [isPublic, setIsPublic] = useState(true);
  const [fotoUrl, setFotoUrl] = useState('');
  const [fotoLoading, setFotoLoading] = useState(false);

  // Elder-friendly Easy Captcha
  const [swipeVerified, setSwipeVerified] = useState(false);
  const [isSwiping, setIsSwiping] = useState(false);
  const [sliderPosition, setSliderPosition] = useState(0);

  // App States
  const [submitting, setSubmitting] = useState(false);
  const [successTicket, setSuccessTicket] = useState<{ ticketNumber: string; id: string } | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const sliderContainerRef = useRef<HTMLDivElement>(null);

  // Handle image selection and compression to base64
  const handleImageChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setErrorMsg('Ukuran foto terlalu besar. Maksimal adalah 5MB.');
      return;
    }

    setFotoLoading(true);
    const reader = new FileReader();
    reader.onloadend = () => {
      setFotoUrl(reader.result as string);
      setFotoLoading(false);
    };
    reader.onerror = () => {
      setErrorMsg('Gagal membaca file foto.');
      setFotoLoading(false);
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setErrorMsg('Ukuran foto terlalu besar. Maksimal adalah 5MB.');
      return;
    }

    setFotoLoading(true);
    const reader = new FileReader();
    reader.onloadend = () => {
      setFotoUrl(reader.result as string);
      setFotoLoading(false);
    };
    reader.readAsDataURL(file);
  };

  // Swipe-to-Verify Logic
  const handleTouchStart = () => {
    setIsSwiping(true);
  };

  const handleTouchMove = (e: TouchEvent) => {
    if (!isSwiping || swipeVerified || !sliderContainerRef.current) return;
    const containerWidth = sliderContainerRef.current.clientWidth;
    const touchX = e.touches[0].clientX;
    const containerLeft = sliderContainerRef.current.getBoundingClientRect().left;
    let position = touchX - containerLeft - 22; // Subtract half slider handle width (44px/2)

    const maxPosition = containerWidth - 48; // Subtract slider width
    if (position < 0) position = 0;
    if (position > maxPosition) position = maxPosition;

    setSliderPosition(position);

    if (position >= maxPosition - 5) {
      setSwipeVerified(true);
      setIsSwiping(false);
      setSliderPosition(maxPosition);
    }
  };

  const handleTouchEnd = () => {
    if (!swipeVerified) {
      setIsSwiping(false);
      setSliderPosition(0);
    }
  };

  const handleMouseDown = () => {
    setIsSwiping(true);
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isSwiping || swipeVerified || !sliderContainerRef.current) return;
    const containerWidth = sliderContainerRef.current.clientWidth;
    const mouseX = e.clientX;
    const containerLeft = sliderContainerRef.current.getBoundingClientRect().left;
    let position = mouseX - containerLeft - 22;

    const maxPosition = containerWidth - 48;
    if (position < 0) position = 0;
    if (position > maxPosition) position = maxPosition;

    setSliderPosition(position);

    if (position >= maxPosition - 5) {
      setSwipeVerified(true);
      setIsSwiping(false);
      setSliderPosition(maxPosition);
    }
  };

  const handleMouseUp = () => {
    if (!swipeVerified) {
      setIsSwiping(false);
      setSliderPosition(0);
    }
  };

  // Submit Handler
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!judul.trim()) {
      setErrorMsg('Judul pengaduan wajib diisi.');
      return;
    }
    if (!isi.trim()) {
      setErrorMsg('Isi laporan pengaduan wajib diisi.');
      return;
    }
    if (!kategori) {
      setErrorMsg('Silakan pilih kategori laporan Anda.');
      return;
    }
    if (!swipeVerified) {
      setErrorMsg('Silakan geser tombol di bawah ke kanan untuk memverifikasi Anda bukan robot.');
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        judul: judul.trim(),
        isi: isi.trim(),
        kategori,
        nama: isAnonim ? 'Warga Ringintunggal' : (nama.trim() || 'Anonim'),
        whatsapp: whatsapp.trim() || undefined,
        is_anonim: isAnonim,
        is_public: isPublic,
        foto_url: fotoUrl || undefined,
      };

      const res = await dataService.createComplaint(payload);

      if (res.isDemo) {
        setDemoNotification(true);
      }

      setSuccessTicket({
        ticketNumber: res.data.ticket_number || 'RGT-PENDING',
        id: res.data.id,
      });

      // Clear Form
      setJudul('');
      setIsi('');
      setKategori('');
      setNama('');
      setWhatsapp('');
      setFotoUrl('');
      setSwipeVerified(false);
      setSliderPosition(0);
    } catch (err: any) {
      setErrorMsg(err.message || 'Gagal mengirimkan laporan. Silakan coba beberapa saat lagi.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto px-4 pt-6 pb-24">
      {/* Back button */}
      <button
        id="btn-back-home"
        onClick={() => onNavigate('beranda')}
        className="inline-flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-slate-800 mb-6 group cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
        Kembali ke Beranda
      </button>

      {/* Title */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight font-display mb-1.5">
          Sampaikan Pengaduan
        </h1>
        <p className="text-xs text-slate-500 leading-relaxed">
          Silakan lengkapi formulir berikut dengan informasi yang akurat agar petugas Desa Ringintunggal dapat menindaklanjuti laporan Anda secepatnya.
        </p>
      </div>

      {successTicket ? (
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 text-center shadow-sm"
        >
          <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-emerald-600" />
          </div>
          <h2 className="text-lg font-bold text-emerald-800 mb-1">Laporan Berhasil Terkirim!</h2>
          <p className="text-xs text-emerald-700 leading-relaxed mb-6">
            Laporan Anda telah tercatat dalam sistem pelayanan Desa Ringintunggal. Simpan nomor tiket berikut untuk melakukan pelacakan secara berkala.
          </p>

          <div className="bg-white rounded-xl border border-emerald-200 p-4 mb-6">
            <span className="block text-[10px] text-slate-400 uppercase tracking-wider mb-1 font-semibold">Nomor Tiket Anda</span>
            <span className="text-xl font-bold font-mono text-[#0F766E] tracking-wider block">
              {successTicket.ticketNumber}
            </span>
          </div>

          <div className="flex flex-col gap-2">
            <button
              id="btn-view-ticket"
              onClick={() => onNavigate('detail', successTicket.id)}
              className="w-full bg-[#0F766E] hover:bg-[#0D5C56] text-white font-semibold text-sm rounded-xl py-3 transition-colors cursor-pointer"
            >
              Lihat Detail Laporan
            </button>
            <button
              id="btn-write-another"
              onClick={() => setSuccessTicket(null)}
              className="w-full text-slate-600 hover:text-slate-800 font-medium text-xs py-2 transition-colors cursor-pointer"
            >
              Kirim Laporan Lainnya
            </button>
          </div>
        </motion.div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-5">
          {errorMsg && (
            <div className="bg-rose-50 border border-rose-200 rounded-xl p-3.5 text-xs text-rose-700 flex gap-2 items-start">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Kategori */}
          <div className="space-y-1.5">
            <label className="block text-sm font-bold text-slate-700">
              Kategori Pengaduan <span className="text-rose-500">*</span>
            </label>
            <p className="text-[11px] text-slate-400">Pilih topik permasalahan yang ingin Anda laporkan.</p>
            <select
              value={kategori}
              onChange={(e) => setKategori(e.target.value as KategoriType)}
              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#0F766E] focus:ring-2 focus:ring-[#0F766E]/10"
              required
            >
              <option value="" disabled>--- Pilih Kategori ---</option>
              {KATEGORI_LIST.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Judul */}
          <div className="space-y-1.5">
            <label className="block text-sm font-bold text-slate-700">
              Judul Pengaduan <span className="text-rose-500">*</span>
            </label>
            <p className="text-[11px] text-slate-400">Gunakan kalimat singkat yang menggambarkan inti keluhan Anda.</p>
            <input
              type="text"
              placeholder="Contoh: Lampu jalan depan mushola mati total"
              value={judul}
              onChange={(e) => setJudul(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-sm placeholder:text-slate-400 focus:outline-none focus:border-[#0F766E] focus:ring-2 focus:ring-[#0F766E]/10"
              required
            />
          </div>

          {/* Isi Pengaduan */}
          <div className="space-y-1.5">
            <label className="block text-sm font-bold text-slate-700">
              Isi Laporan Pengaduan <span className="text-rose-500">*</span>
            </label>
            <p className="text-[11px] text-slate-400">Tulis secara detail mengenai waktu, lokasi, kronologi kejadian, atau permasalahan.</p>
            <textarea
              rows={5}
              placeholder="Jelaskan laporan lengkap Anda di sini..."
              value={isi}
              onChange={(e) => setIsi(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-sm placeholder:text-slate-400 focus:outline-none focus:border-[#0F766E] focus:ring-2 focus:ring-[#0F766E]/10 leading-relaxed"
              required
            />
          </div>

          {/* Foto Bukti */}
          <div className="space-y-1.5">
            <label className="block text-sm font-bold text-slate-700">
              Foto Bukti <span className="text-slate-400 font-normal">(Opsional)</span>
            </label>
            <p className="text-[11px] text-slate-400">Unggah foto penunjang agar laporan Anda lebih kuat dan mudah ditindaklanjuti.</p>

            <div
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-200 rounded-xl p-5 bg-white text-center hover:border-[#0F766E] transition-colors cursor-pointer"
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImageChange}
                accept="image/*"
                className="hidden"
              />
              {fotoUrl ? (
                <div className="relative">
                  <img
                    src={fotoUrl}
                    alt="Pratinjau Bukti"
                    className="max-h-48 mx-auto rounded-lg object-cover"
                  />
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setFotoUrl('');
                    }}
                    className="absolute top-2 right-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-full p-1 shadow"
                  >
                    Hapus
                  </button>
                </div>
              ) : fotoLoading ? (
                <div className="text-slate-500 text-xs py-4 flex flex-col items-center gap-1.5">
                  <div className="w-5 h-5 border-2 border-[#0F766E] border-t-transparent rounded-full animate-spin"></div>
                  Membaca berkas foto...
                </div>
              ) : (
                <div className="space-y-2 py-3 text-slate-500">
                  <Upload className="w-8 h-8 text-slate-400 mx-auto" />
                  <p className="text-xs font-medium">Klik untuk pilih foto, atau seret foto ke sini</p>
                  <p className="text-[10px] text-slate-400">Mendukung file gambar (.jpg, .png, .webp) maks. 5MB</p>
                </div>
              )}
            </div>
          </div>

          {/* Tipe Laporan (Anonim vs Publik) */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100 space-y-4">
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-0.5">
                <span className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                  Kirim Sebagai Anonim
                </span>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Nama dan nomor WhatsApp Anda disembunyikan dari halaman publik dan hanya akan tampil sebagai "Warga Ringintunggal".
                </p>
              </div>
              <button
                type="button"
                id="btn-toggle-anonim"
                onClick={() => setIsAnonim(!isAnonim)}
                className={`w-12 h-6 rounded-full p-0.5 transition-colors focus:outline-none ${isAnonim ? 'bg-[#0F766E]' : 'bg-slate-300'}`}
              >
                <div className={`bg-white w-5 h-5 rounded-full shadow-md transform transition-transform duration-200 ${isAnonim ? 'translate-x-6' : 'translate-x-0'}`} />
              </button>
            </div>

            {/* Nama Pelapor & WhatsApp (Shown/Modified based on selection) */}
            <div className={`space-y-3 transition-opacity duration-300 ${isAnonim ? 'opacity-60 pointer-events-none' : 'opacity-100'}`}>
              <div className="grid grid-cols-1 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600 flex items-center gap-1">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    Nama Pelapor <span className="text-slate-400 font-normal">(Opsional)</span>
                  </label>
                  <input
                    type="text"
                    placeholder="Masukkan nama lengkap Anda"
                    value={nama}
                    disabled={isAnonim}
                    onChange={(e) => setNama(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-2 text-xs focus:outline-none focus:border-[#0F766E]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600 flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    Nomor WhatsApp <span className="text-slate-400 font-normal">(Opsional)</span>
                  </label>
                  <input
                    type="tel"
                    placeholder="Contoh: 081234567890"
                    value={whatsapp}
                    disabled={isAnonim}
                    onChange={(e) => setWhatsapp(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-2 text-xs focus:outline-none focus:border-[#0F766E]"
                  />
                  <p className="text-[9px] text-slate-400 leading-snug">
                    Nomor WA tidak akan dipublikasikan. Hanya digunakan oleh staf desa untuk koordinasi tindak lanjut.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Visibility Controls */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100 space-y-1.5">
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-0.5">
                <span className="text-sm font-bold text-slate-800">Tampilkan ke Publik</span>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Laporan akan muncul di halaman beranda utama agar warga lain dapat melihat perkembangan dan memberikan dukungan.
                </p>
              </div>
              <button
                type="button"
                id="btn-toggle-public"
                onClick={() => setIsPublic(!isPublic)}
                className={`w-12 h-6 rounded-full p-0.5 transition-colors focus:outline-none ${isPublic ? 'bg-[#0F766E]' : 'bg-slate-300'}`}
              >
                <div className={`bg-white w-5 h-5 rounded-full shadow-md transform transition-transform duration-200 ${isPublic ? 'translate-x-6' : 'translate-x-0'}`} />
              </button>
            </div>
          </div>

          {/* Elderly Friendly Anti-Spam Widget */}
          <div className="border border-slate-100 bg-teal-50/20 rounded-2xl p-4 text-center">
            <span className="block text-xs font-bold text-slate-700 mb-2 flex items-center justify-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#0F766E]" />
              Verifikasi Keamanan Warga (Anti-Spam)
            </span>
            <p className="text-[11px] text-slate-500 mb-3">Geser tombol di bawah ke ujung kanan untuk mengirim laporan Anda.</p>

            <div
              ref={sliderContainerRef}
              className="h-12 bg-slate-100 rounded-full relative overflow-hidden flex items-center px-1 select-none border border-slate-200"
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
            >
              {/* Slider Track background text */}
              <div className="absolute inset-0 flex items-center justify-center text-[11px] font-semibold text-slate-400 pointer-events-none">
                {swipeVerified ? '✅ VERIFIKASI BERHASIL' : '>>> GESER KE KANAN >>>'}
              </div>

              {/* Verified progress color */}
              <div
                className="bg-[#0F766E]/20 h-full absolute left-0 top-0 transition-all rounded-full"
                style={{ width: `${sliderPosition + 44}px` }}
              />

              {/* Slider handle */}
              <div
                id="slider-verification-handle"
                className={`w-11 h-11 bg-[#0F766E] hover:bg-[#0D5C56] text-white rounded-full flex items-center justify-center shadow-md absolute cursor-grab active:cursor-grabbing transition-colors duration-150`}
                style={{ left: `${sliderPosition}px` }}
                onTouchStart={handleTouchStart}
                onTouchMove={handleTouchMove}
                onTouchEnd={handleTouchEnd}
                onMouseDown={handleMouseDown}
              >
                <span className="text-sm font-bold">➔</span>
              </div>
            </div>
          </div>

          {/* Form Submit Button */}
          <button
            id="btn-submit-laporan"
            type="submit"
            disabled={submitting || !swipeVerified}
            className={`w-full py-3.5 px-4 rounded-xl font-bold text-sm tracking-wide shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer ${
              swipeVerified
                ? 'bg-[#0F766E] text-white hover:bg-[#0D5C56]'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
            }`}
          >
            {submitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                Sedang Mengirim Laporan...
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                Kirim Laporan Pengaduan
              </>
            )}
          </button>
        </form>
      )}
    </div>
  );
}
