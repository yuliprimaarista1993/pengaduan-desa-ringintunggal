import { useState, useEffect, FormEvent, MouseEvent } from 'react';
import { motion } from 'motion/react';
import { LogOut, Filter, MessageSquare, Clock, Trash2, ArrowRight, UserCheck, Settings, Search, RefreshCw, Smartphone, Mail, MapPin } from 'lucide-react';
import { Pengaduan } from '../types';
import { dataService } from '../lib/dataService';

interface AdminDashboardProps {
  onNavigate: (view: 'beranda' | 'buat-pengaduan' | 'detail' | 'login-admin' | 'admin-dashboard', ticketId?: string) => void;
  onLogout: () => void;
  adminEmail: string | null;
  setDemoNotification: (val: boolean) => void;
}

export default function AdminDashboard({ onNavigate, onLogout, adminEmail, setDemoNotification }: AdminDashboardProps) {
  const [complaints, setComplaints] = useState<Pengaduan[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ total: 0, new: 0, processing: 0, completed: 0 });
  const [activeTab, setActiveTab] = useState<'all' | 'new' | 'processing' | 'completed' | 'settings'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isDemo, setIsDemo] = useState(false);

  // Portal Settings State (from localStorage or defaults)
  const [villageName, setVillageName] = useState('Ringintunggal');
  const [villageContact, setVillageContact] = useState('0812-3456-7890');
  const [villageEmail, setVillageEmail] = useState('desa.ringintunggal@gmail.com');
  const [villageAddress, setVillageAddress] = useState('Jl. Raya Ringintunggal No. 01, Kec. Gayam, Kabupaten Bojonegoro, Jawa Timur');
  const [settingsSaved, setSettingsSaved] = useState(false);

  useEffect(() => {
    // Load village settings from storage if any
    const savedName = localStorage.getItem('village_name');
    const savedContact = localStorage.getItem('village_contact');
    const savedEmail = localStorage.getItem('village_email');
    const savedAddress = localStorage.getItem('village_address');
    if (savedName) setVillageName(savedName);
    if (savedContact) setVillageContact(savedContact);
    if (savedEmail) setVillageEmail(savedEmail);
    if (savedAddress) setVillageAddress(savedAddress);
  }, []);

  useEffect(() => {
    fetchData();
  }, [activeTab, searchQuery]);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Map tabs to filter statuses
      let statusFilter = '';
      if (activeTab === 'new') statusFilter = 'Menunggu Verifikasi';
      if (activeTab === 'processing') statusFilter = 'Diproses';
      if (activeTab === 'completed') statusFilter = 'Selesai';

      const res = await dataService.searchAndFilterComplaints(searchQuery, statusFilter, '', '');
      setComplaints(res.data);
      setIsDemo(res.isDemo);

      const counts = await dataService.getComplaintCount();
      setStats({
        total: counts.total,
        new: counts.new,
        processing: counts.processing,
        completed: counts.completed,
      });

      if (counts.isDemo) {
        setDemoNotification(true);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveSettings = (e: FormEvent) => {
    e.preventDefault();
    localStorage.setItem('village_name', villageName);
    localStorage.setItem('village_contact', villageContact);
    localStorage.setItem('village_email', villageEmail);
    localStorage.setItem('village_address', villageAddress);
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 2000);
  };

  const handleDelete = async (id: string, e: MouseEvent) => {
    e.stopPropagation();
    const confirmDelete = window.confirm('Apakah Anda yakin ingin menghapus laporan ini? Tindakan ini permanen.');
    if (!confirmDelete) return;

    try {
      await dataService.deleteComplaint(id);
      await fetchData();
    } catch (err: any) {
      alert(err.message || 'Gagal menghapus laporan.');
    }
  };

  const getStatusColor = (status: Pengaduan['status']) => {
    switch (status) {
      case 'Menunggu Verifikasi': return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Diproses': return 'bg-teal-100 text-teal-800 border-teal-200';
      case 'Selesai': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Ditolak': return 'bg-rose-100 text-rose-800 border-rose-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      });
    } catch (e) {
      return dateStr;
    }
  };

  return (
    <div className="max-w-xl mx-auto px-4 pt-6 pb-24">
      {/* Admin Header controls */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <span className="text-[10px] bg-slate-900 text-teal-400 font-bold px-2.5 py-1 rounded-full border border-slate-800 tracking-wider">
            ADMIN PANEL
          </span>
          <p className="text-xs text-slate-500 font-mono mt-1">{adminEmail || 'admin@ringintunggal.desa.id'}</p>
        </div>
        <button
          id="btn-admin-logout"
          onClick={onLogout}
          className="inline-flex items-center gap-1 text-xs font-semibold text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 px-3 py-2 rounded-xl transition-colors cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          Keluar
        </button>
      </div>

      {/* Core Statistics panel */}
      <div className="grid grid-cols-4 gap-2 mb-6">
        <div
          onClick={() => setActiveTab('all')}
          className={`p-3 rounded-xl border text-center cursor-pointer transition-all ${
            activeTab === 'all' ? 'bg-[#0F766E]/5 border-[#0F766E]' : 'bg-white border-slate-100'
          }`}
        >
          <span className="block text-lg font-bold text-slate-800 leading-none">{stats.total}</span>
          <span className="text-[9px] font-medium text-slate-400">Total</span>
        </div>

        <div
          onClick={() => setActiveTab('new')}
          className={`p-3 rounded-xl border text-center cursor-pointer transition-all ${
            activeTab === 'new' ? 'bg-amber-50 border-amber-300' : 'bg-white border-slate-100'
          }`}
        >
          <span className="block text-lg font-bold text-amber-700 leading-none">{stats.new}</span>
          <span className="text-[9px] font-medium text-slate-400">Baru</span>
        </div>

        <div
          onClick={() => setActiveTab('processing')}
          className={`p-3 rounded-xl border text-center cursor-pointer transition-all ${
            activeTab === 'processing' ? 'bg-teal-50 border-teal-300' : 'bg-white border-slate-100'
          }`}
        >
          <span className="block text-lg font-bold text-teal-700 leading-none">{stats.processing}</span>
          <span className="text-[9px] font-medium text-slate-400">Proses</span>
        </div>

        <div
          onClick={() => setActiveTab('completed')}
          className={`p-3 rounded-xl border text-center cursor-pointer transition-all ${
            activeTab === 'completed' ? 'bg-emerald-50 border-emerald-300' : 'bg-white border-slate-100'
          }`}
        >
          <span className="block text-lg font-bold text-emerald-700 leading-none">{stats.completed}</span>
          <span className="text-[9px] font-medium text-slate-400">Selesai</span>
        </div>
      </div>

      {/* Admin Dashboard Menu Tabs */}
      <div className="flex border-b border-slate-200 mb-5 text-xs overflow-x-auto whitespace-nowrap scrollbar-none gap-2">
        <button
          id="btn-tab-all"
          onClick={() => setActiveTab('all')}
          className={`pb-2.5 px-3 font-bold cursor-pointer transition-all ${activeTab === 'all' ? 'text-[#0F766E] border-b-2 border-[#0F766E]' : 'text-slate-400'}`}
        >
          Semua Pengaduan
        </button>
        <button
          id="btn-tab-new"
          onClick={() => setActiveTab('new')}
          className={`pb-2.5 px-3 font-bold cursor-pointer transition-all ${activeTab === 'new' ? 'text-amber-700 border-b-2 border-amber-500' : 'text-slate-400'}`}
        >
          Baru
        </button>
        <button
          id="btn-tab-processing"
          onClick={() => setActiveTab('processing')}
          className={`pb-2.5 px-3 font-bold cursor-pointer transition-all ${activeTab === 'processing' ? 'text-teal-700 border-b-2 border-teal-500' : 'text-slate-400'}`}
        >
          Diproses
        </button>
        <button
          id="btn-tab-completed"
          onClick={() => setActiveTab('completed')}
          className={`pb-2.5 px-3 font-bold cursor-pointer transition-all ${activeTab === 'completed' ? 'text-emerald-700 border-b-2 border-emerald-500' : 'text-slate-400'}`}
        >
          Selesai
        </button>
        <button
          id="btn-tab-settings"
          onClick={() => setActiveTab('settings')}
          className={`pb-2.5 px-3 font-bold cursor-pointer transition-all flex items-center gap-1 ${activeTab === 'settings' ? 'text-indigo-600 border-b-2 border-indigo-500' : 'text-slate-400'}`}
        >
          <Settings className="w-3.5 h-3.5" />
          Pengaturan Website
        </button>
      </div>

      {activeTab === 'settings' ? (
        /* Settings module */
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm space-y-4"
        >
          <div>
            <h3 className="text-sm font-bold text-slate-800 mb-1.5 flex items-center gap-1.5">
              ⚙️ Pengaturan Dasar Desa
            </h3>
            <p className="text-[11px] text-slate-500 leading-normal">
              Atur parameter informasi desa yang ditampilkan pada portal laporan warga Desa Ringintunggal.
            </p>
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-4 pt-2">
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-600">Nama Desa</label>
              <input
                type="text"
                value={villageName}
                onChange={(e) => setVillageName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#0F766E]"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-600">Nomor Kontak WhatsApp Desa</label>
              <input
                type="text"
                value={villageContact}
                onChange={(e) => setVillageContact(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#0F766E]"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-600">Email Hubungan Masyarakat</label>
              <input
                type="email"
                value={villageEmail}
                onChange={(e) => setVillageEmail(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#0F766E]"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-600">Alamat Kantor Desa</label>
              <textarea
                rows={3}
                value={villageAddress}
                onChange={(e) => setVillageAddress(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#0F766E] leading-relaxed"
                required
              />
            </div>

            {settingsSaved && (
              <p className="text-xs text-emerald-600 font-bold flex items-center gap-1">
                ✓ Pengaturan berhasil disimpan ke penyimpanan sistem.
              </p>
            )}

            <button
              id="btn-save-settings"
              type="submit"
              className="w-full bg-[#0F766E] hover:bg-[#0D5C56] text-white text-xs font-bold py-2.5 rounded-xl cursor-pointer transition-colors"
            >
              Simpan Perubahan
            </button>
          </form>
        </motion.div>
      ) : (
        /* Complaints Listing with search */
        <div className="space-y-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Cari berdasarkan tiket, judul, isi..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-2xl pl-10 pr-4 py-2.5 text-xs focus:outline-none focus:border-[#0F766E]"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          </div>

          <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider py-1 border-b border-slate-100">
            <span>Daftar Laporan Warga ({complaints.length})</span>
            {loading && <RefreshCw className="w-3.5 h-3.5 animate-spin text-teal-600" />}
          </div>

          {complaints.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 border border-slate-100 text-center shadow-sm">
              <p className="text-xs text-slate-400">Tidak ada pengaduan warga pada kategori ini.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {complaints.map((c) => (
                <div
                  key={c.id}
                  onClick={() => onNavigate('detail', c.id)}
                  className="bg-white rounded-xl border border-slate-150 p-4 hover:border-[#0F766E]/40 shadow-sm transition-all duration-150 cursor-pointer flex flex-col justify-between gap-3 relative overflow-hidden"
                >
                  <div className="flex justify-between items-start gap-2">
                    <div>
                      <span className="text-[10px] font-mono font-bold text-[#0F766E] block">
                        {c.ticket_number || 'RGT-PENDING'}
                      </span>
                      <span className="inline-block text-[9px] font-bold bg-slate-100 text-slate-500 rounded px-1.5 py-0.5 mt-0.5">
                        {c.kategori}
                      </span>
                    </div>

                    <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full border ${getStatusColor(c.status)}`}>
                      {c.status}
                    </span>
                  </div>

                  <div>
                    <h4 className="text-xs font-bold text-slate-900 line-clamp-1 mb-1 leading-snug">
                      {c.judul}
                    </h4>
                    <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                      {c.isi}
                    </p>
                  </div>

                  {/* Contact trail for auditing */}
                  <div className="bg-slate-50 rounded-lg p-2 flex items-center justify-between text-[10px] border border-slate-100">
                    <span className="text-slate-600">
                      Pelapor: <span className="font-bold text-slate-800">{c.nama || 'Anonim'}</span>
                      {c.is_anonim && <span className="text-slate-400 italic font-normal ml-1">(Pilih Anonim di Publik)</span>}
                    </span>
                    {c.whatsapp && (
                      <span className="font-mono text-slate-500 font-semibold">{c.whatsapp}</span>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-400 pt-2 border-t border-slate-50">
                    <span>Masuk: {formatDate(c.created_at)}</span>
                    <div className="flex items-center gap-1.5">
                      <button
                        id={`btn-del-com-${c.id}`}
                        onClick={(e) => handleDelete(c.id, e)}
                        className="p-1 text-rose-600 hover:bg-rose-50 rounded transition-colors"
                        title="Hapus Pengaduan"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                      <span className="text-[#0F766E] flex items-center gap-0.5 font-bold">
                        Buka Detail <ArrowRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
