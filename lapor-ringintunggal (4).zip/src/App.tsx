import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Home, PlusCircle, ShieldAlert, BookOpen, Clock, Heart, PhoneCall, MailCheck } from 'lucide-react';
import Beranda from './components/Beranda';
import BuatPengaduan from './components/BuatPengaduan';
import DetailPengaduan from './components/DetailPengaduan';
import LoginAdmin from './components/LoginAdmin';
import AdminDashboard from './components/AdminDashboard';

type ViewType = 'beranda' | 'buat-pengaduan' | 'detail' | 'login-admin' | 'admin-dashboard';

export default function App() {
  const [view, setView] = useState<ViewType>('beranda');
  const [selectedTicketId, setSelectedTicketId] = useState<string | undefined>(undefined);

  // Authentication states
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [adminEmail, setAdminEmail] = useState<string | null>(null);

  // Fallback demo indicator banner
  const [demoNotification, setDemoNotification] = useState(false);

  // Village Settings fallback from storage or static
  const [villageName, setVillageName] = useState('Ringintunggal');
  const [villageContact, setVillageContact] = useState('0812-3456-7890');

  useEffect(() => {
    // Restore Admin Session from localStorage
    const savedAdmin = localStorage.getItem('lapor_admin_session');
    if (savedAdmin) {
      const parsed = JSON.parse(savedAdmin);
      setIsAdminLoggedIn(true);
      setAdminEmail(parsed.email);
    }

    // Read general village settings if saved
    const savedName = localStorage.getItem('village_name');
    const savedContact = localStorage.getItem('village_contact');
    if (savedName) setVillageName(savedName);
    if (savedContact) setVillageContact(savedContact);
  }, [view]);

  const handleLoginSuccess = (email: string, token?: string) => {
    setIsAdminLoggedIn(true);
    setAdminEmail(email);
    localStorage.setItem(
      'lapor_admin_session',
      JSON.stringify({ email, token, timestamp: Date.now() })
    );
  };

  const handleLogout = () => {
    setIsAdminLoggedIn(false);
    setAdminEmail(null);
    localStorage.removeItem('lapor_admin_session');
    setView('beranda');
  };

  const handleNavigation = (targetView: ViewType, ticketId?: string) => {
    if (ticketId) {
      setSelectedTicketId(ticketId);
    }
    setView(targetView);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans relative">
      {/* Top Banner Navigation Header */}
      <header className="sticky top-0 z-40 bg-[#0F766E] text-white px-4 py-3.5 shadow-md border-b border-[#0F766E]/20">
        <div className="max-w-xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => handleNavigation('beranda')}>
            <img
              src="https://i.ibb.co.com/tTzpHtJc/logo-ringintunggal-1.webp"
              alt="Logo Ringintunggal"
              className="w-8 h-8 object-contain bg-white rounded-full p-0.5"
              referrerPolicy="no-referrer"
            />
            <div>
              <span className="font-display font-bold text-sm tracking-tight block">Lapor Ringintunggal</span>
              <span className="text-[9px] text-teal-100 font-medium block">Portal Pengaduan Resmi Desa</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isAdminLoggedIn ? (
              <button
                id="header-btn-admin-dashboard"
                onClick={() => handleNavigation('admin-dashboard')}
                className="text-[10px] font-bold uppercase tracking-wider bg-[#14B8A6] hover:bg-teal-400 text-slate-950 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
              >
                Dasbor Admin
              </button>
            ) : (
              <button
                id="header-btn-admin-login"
                onClick={() => handleNavigation('login-admin')}
                className="text-[10px] font-bold uppercase tracking-wider bg-transparent hover:bg-white/10 text-white border border-white/30 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
              >
                Login Staff
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 w-full max-w-xl mx-auto bg-slate-50 relative">
        <AnimatePresence mode="wait">
          <motion.div
            key={view + (selectedTicketId || '')}
            initial={{ opacity: 0, x: 5 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -5 }}
            transition={{ duration: 0.15 }}
          >
            {view === 'beranda' && (
              <Beranda
                onNavigate={handleNavigation}
                demoNotification={demoNotification}
                setDemoNotification={setDemoNotification}
              />
            )}

            {view === 'buat-pengaduan' && (
              <BuatPengaduan
                onNavigate={handleNavigation}
                setDemoNotification={setDemoNotification}
              />
            )}

            {view === 'detail' && selectedTicketId && (
              <DetailPengaduan
                id={selectedTicketId}
                onNavigate={handleNavigation}
                isAdmin={isAdminLoggedIn}
                adminEmail={adminEmail}
                setDemoNotification={setDemoNotification}
              />
            )}

            {view === 'login-admin' && (
              <LoginAdmin
                onNavigate={handleNavigation}
                onLoginSuccess={handleLoginSuccess}
                setDemoNotification={setDemoNotification}
              />
            )}

            {view === 'admin-dashboard' && (
              <AdminDashboard
                onNavigate={handleNavigation}
                onLogout={handleLogout}
                adminEmail={adminEmail}
                setDemoNotification={setDemoNotification}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer Info (Seniors Supportive Contact Info) */}
      <footer className="bg-slate-900 text-slate-400 pt-8 pb-24 px-4 text-center border-t border-slate-800">
        <div className="max-w-xl mx-auto space-y-4">
          <img
            src="https://i.ibb.co.com/tTzpHtJc/logo-ringintunggal-1.webp"
            alt="Logo Desa"
            className="w-12 h-12 mx-auto object-contain opacity-90 filter brightness-110 drop-shadow-md"
            referrerPolicy="no-referrer"
          />
          <div className="space-y-1">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Pemerintah Desa Ringintunggal</h4>
            <p className="text-[10px] leading-relaxed">
              Kecamatan Gayam, Kabupaten Bojonegoro, Jawa Timur
            </p>
          </div>

          <p className="text-[9px] text-slate-500 pt-2 border-t border-slate-800/80">
            © 2026 Desa Ringintunggal. Dikembangkan sebagai sistem pelayanan aspirasi transparan.
          </p>
        </div>
      </footer>

      {/* Bottom Mobile Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-100 shadow-xl py-2 px-6 safe-bottom">
        <div className="max-w-md mx-auto flex justify-around items-center">
          {/* Tab Beranda */}
          <button
            id="nav-tab-beranda"
            onClick={() => handleNavigation('beranda')}
            className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
              view === 'beranda' || view === 'detail' ? 'text-[#0F766E]' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px] font-semibold">Beranda</span>
          </button>

          {/* Tab Buat Pengaduan */}
          <button
            id="nav-tab-buat-pengaduan"
            onClick={() => handleNavigation('buat-pengaduan')}
            className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
              view === 'buat-pengaduan' ? 'text-[#0F766E]' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <PlusCircle className="w-5 h-5" />
            <span className="text-[10px] font-semibold">Buat Laporan</span>
          </button>

          {/* Tab Admin */}
          <button
            id="nav-tab-admin"
            onClick={() => handleNavigation(isAdminLoggedIn ? 'admin-dashboard' : 'login-admin')}
            className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
              view === 'login-admin' || view === 'admin-dashboard' ? 'text-[#0F766E]' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <ShieldAlert className="w-5 h-5" />
            <span className="text-[10px] font-semibold">{isAdminLoggedIn ? 'Dasbor' : 'Staf Desa'}</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
